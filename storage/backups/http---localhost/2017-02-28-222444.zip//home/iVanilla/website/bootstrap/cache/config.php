<?php return array (
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'searchy' => 
  array (
    'default' => 'fuzzy',
    'fieldName' => 'relevance',
    'drivers' => 
    array (
      'fuzzy' => 
      array (
        'class' => 'TomLingham\\Searchy\\SearchDrivers\\FuzzySearchDriver',
      ),
      'simple' => 
      array (
        'class' => 'TomLingham\\Searchy\\SearchDrivers\\SimpleSearchDriver',
      ),
      'levenshtein' => 
      array (
        'class' => 'TomLingham\\Searchy\\SearchDrivers\\LevenshteinSearchDriver',
      ),
    ),
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => '/home/iVanilla/website/resources/views',
    ),
    'compiled' => '/home/iVanilla/website/storage/framework/views',
  ),
  'markdown' => 
  array (
    'xss' => true,
    'urls' => true,
    'escape_markup' => false,
    'breaks' => true,
  ),
  'taggable' => 
  array (
    'delimiters' => ',;',
    'glue' => ',',
    'normalizer' => 'mb_strtolower',
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 120,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => '/home/iVanilla/website/storage/framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
  ),
  'recaptcha' => 
  array (
    'public_key' => '6LcmfBYUAAAAAIi6U5_TyNmhhfSLGrtVMz2Tt-1a',
    'private_key' => '6LcmfBYUAAAAAFWHlnhwBTLZcK3-zV5-h8ONVfuZ',
    'template' => '',
    'driver' => 'curl',
    'options' => 
    array (
      'lang' => 'zh-cn',
      'curl_timeout' => 1,
    ),
    'version' => 2,
  ),
  'app' => 
  array (
    'name' => 'mpcblab',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'timezone' => 'Asia/Shanghai',
    'locale' => 'zh-cn',
    'fallback_locale' => 'en',
    'key' => 'base64:+jXS930f5kH/e6ekj82nbvXfe3JLu3wUTPOtvQAuyPw=',
    'cipher' => 'AES-256-CBC',
    'log' => 'daily',
    'log_level' => 'debug',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'Laravel\\Tinker\\TinkerServiceProvider',
      23 => 'Laravel\\Passport\\PassportServiceProvider',
      24 => 'App\\Providers\\AppServiceProvider',
      25 => 'App\\Providers\\AuthServiceProvider',
      26 => 'App\\Providers\\BroadcastServiceProvider',
      27 => 'App\\Providers\\ComposerServiceProvider',
      28 => 'App\\Providers\\EventServiceProvider',
      29 => 'App\\Providers\\RouteServiceProvider',
      30 => 'Laracasts\\Flash\\FlashServiceProvider',
      31 => 'Indal\\Markdown\\MarkdownServiceProvider',
      32 => 'Stevenyangecho\\UEditor\\UEditorServiceProvider',
      33 => 'Hootlex\\Moderation\\ModerationServiceProvider',
      34 => 'Zizaco\\Entrust\\EntrustServiceProvider',
      35 => 'Cviebrock\\EloquentTaggable\\ServiceProvider',
      36 => 'Intervention\\Image\\ImageServiceProvider',
      37 => 'Junaidnasir\\Larainvite\\LaraInviteServiceProvider',
      38 => 'Schuppo\\PasswordStrength\\PasswordStrengthServiceProvider',
      39 => 'Recca0120\\Upload\\UploadServiceProvider',
      40 => 'Yajra\\Breadcrumbs\\ServiceProvider',
      41 => 'TomLingham\\Searchy\\SearchyServiceProvider',
      42 => 'Greggilbert\\Recaptcha\\RecaptchaServiceProvider',
      43 => 'Fenos\\Notifynder\\NotifynderServiceProvider',
      44 => 'Backpack\\Base\\BaseServiceProvider',
      45 => 'Backpack\\CRUD\\CrudServiceProvider',
      46 => 'Spatie\\Backup\\BackupServiceProvider',
      47 => 'Backpack\\BackupManager\\BackupManagerServiceProvider',
      48 => 'Backpack\\LangFileManager\\LangFileManagerServiceProvider',
      49 => 'Backpack\\LogManager\\LogManagerServiceProvider',
      50 => 'Backpack\\Settings\\SettingsServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Flash' => 'Laracasts\\Flash\\Flash',
      'Markdown' => 'Indal\\Markdown\\Facade',
      'Image' => 'Intervention\\Image\\Facades\\Image',
      'Invite' => 'Junaidnasir\\Larainvite\\Facades\\Invite',
      'Breadcrumbs' => 'Yajra\\Breadcrumbs\\Facade',
      'Searchy' => 'TomLingham\\Searchy\\Facades\\Searchy',
      'Recaptcha' => 'Greggilbert\\Recaptcha\\Facades\\Recaptcha',
      'Notifynder' => 'Fenos\\Notifynder\\Facades\\Notifynder',
    ),
  ),
  'laravel-backup' => 
  array (
    'backup' => 
    array (
      'name' => 'http://localhost',
      'source' => 
      array (
        'files' => 
        array (
          'include' => 
          array (
            0 => '/home/iVanilla/website',
          ),
          'exclude' => 
          array (
            0 => '/home/iVanilla/website/vendor',
            1 => '/home/iVanilla/website/storage',
          ),
        ),
        'databases' => 
        array (
          0 => 'mysql',
        ),
      ),
      'destination' => 
      array (
        'disks' => 
        array (
          0 => 'backups',
        ),
      ),
    ),
    'cleanup' => 
    array (
      'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
      'defaultStrategy' => 
      array (
        'keepAllBackupsForDays' => 7,
        'keepDailyBackupsForDays' => 16,
        'keepWeeklyBackupsForWeeks' => 8,
        'keepMonthlyBackupsForMonths' => 4,
        'keepYearlyBackupsForYears' => 2,
        'deleteOldestBackupsWhenUsingMoreMegabytesThan' => 5000,
      ),
    ),
    'monitorBackups' => 
    array (
      0 => 
      array (
        'name' => 'http://localhost',
        'disks' => 
        array (
          0 => 'backups',
        ),
        'newestBackupsShouldNotBeOlderThanDays' => 1,
        'storageUsedMayNotBeHigherThanMegabytes' => 5000,
      ),
    ),
    'notifications' => 
    array (
      'handler' => 'Spatie\\Backup\\Notifications\\Notifier',
      'events' => 
      array (
        'whenBackupWasSuccessful' => 
        array (
          0 => 'log',
        ),
        'whenCleanupWasSuccessful' => 
        array (
          0 => 'log',
        ),
        'whenHealthyBackupWasFound' => 
        array (
          0 => 'log',
        ),
        'whenBackupHasFailed' => 
        array (
          0 => 'log',
          1 => 'mail',
        ),
        'whenCleanupHasFailed' => 
        array (
          0 => 'log',
          1 => 'mail',
        ),
        'whenUnHealthyBackupWasFound' => 
        array (
          0 => 'log',
          1 => 'mail',
        ),
      ),
      'mail' => 
      array (
        'from' => 'your@email.com',
        'to' => 'your@email.com',
      ),
      'slack' => 
      array (
        'channel' => '#backups',
        'username' => 'Backup bot',
        'icon' => ':robot:',
      ),
    ),
  ),
  'notifynder' => 
  array (
    'model' => 'App\\Models\\User',
    'polymorphic' => true,
    'strict_extra' => false,
    'translation' => 
    array (
      'enabled' => true,
      'domain' => 'notifynder',
    ),
    'additional_fields' => 
    array (
      'required' => 
      array (
      ),
      'fillable' => 
      array (
      ),
    ),
  ),
  'moderation' => 
  array (
    'status_column' => 'status',
    'moderated_at_column' => 'moderated_at',
    'moderated_by_column' => NULL,
    'strict' => true,
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
    ),
    'ses' => 
    array (
      'key' => NULL,
      'secret' => NULL,
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'stripe' => 
    array (
      'model' => 'App\\User',
      'key' => NULL,
      'secret' => NULL,
    ),
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'database' => 'mpcblab',
        'prefix' => '',
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'mpcblab',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'collation' => 'utf8_unicode_ci',
        'prefix' => '',
        'strict' => true,
        'engine' => 'InnoDB ROW_FORMAT=DYNAMIC',
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'mpcblab',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'default' => 
      array (
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => '/home/iVanilla/website/storage/framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
    ),
    'prefix' => 'laravel',
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'mailtrap.io',
    'port' => '2525',
    'from' => 
    array (
      'address' => 'hello@example.com',
      'name' => 'Example',
    ),
    'encryption' => NULL,
    'username' => NULL,
    'password' => NULL,
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => '/home/iVanilla/website/resources/views/vendor/mail',
      ),
    ),
  ),
  'backpack' => 
  array (
    'langfilemanager' => 
    array (
      'language_ignore' => 
      array (
        0 => 'pagination',
        1 => 'reminders',
        2 => 'validation',
        3 => 'log',
        4 => 'crud',
      ),
    ),
    'crud' => 
    array (
      'default_save_action' => 'save_and_back',
      'tabs_type' => 'horizontal',
      'show_grouped_errors' => true,
      'show_inline_errors' => true,
      'default_page_length' => 25,
      'show_translatable_field_icon' => true,
      'translatable_field_icon_position' => 'right',
      'locales' => 
      array (
        'zh_Hans' => 'Chinese (Simplified Han)',
        'zh_Hant' => 'Chinese (Traditional Han)',
        'en' => 'English',
        'fr' => 'French',
        'it' => 'Italian',
        'ro' => 'Romanian',
      ),
    ),
    'base' => 
    array (
      'project_name' => 'mpcblab',
      'logo_lg' => '<b>Back</b>pack',
      'logo_mini' => '<b>B</b>p',
      'developer_name' => 'iVanilla',
      'developer_link' => 'https://github.com/iVanilla',
      'show_powered_by' => true,
      'skin' => 'skin-green',
      'default_date_format' => 'j F Y',
      'default_datetime_format' => 'j F Y H:i',
      'registration_open' => false,
      'route_prefix' => 'admin',
      'setup_auth_routes' => true,
      'setup_dashboard_routes' => true,
      'user_model_fqn' => '\\App\\Models\\User',
    ),
    'backupmanager' => 
    array (
      'backup' => 
      array (
        'name' => 'http://localhost',
        'source' => 
        array (
          'files' => 
          array (
            'include' => 
            array (
              0 => '/home/iVanilla/website',
            ),
            'exclude' => 
            array (
              0 => '/home/iVanilla/website/vendor',
              1 => '/home/iVanilla/website/storage',
            ),
          ),
          'databases' => 
          array (
            0 => 'mysql',
          ),
        ),
        'destination' => 
        array (
          'disks' => 
          array (
            0 => 'backups',
          ),
        ),
      ),
      'cleanup' => 
      array (
        'strategy' => 'Spatie\\Backup\\Tasks\\Cleanup\\Strategies\\DefaultStrategy',
        'defaultStrategy' => 
        array (
          'keepAllBackupsForDays' => 7,
          'keepDailyBackupsForDays' => 16,
          'keepWeeklyBackupsForWeeks' => 8,
          'keepMonthlyBackupsForMonths' => 4,
          'keepYearlyBackupsForYears' => 2,
          'deleteOldestBackupsWhenUsingMoreMegabytesThan' => 5000,
        ),
      ),
      'monitorBackups' => 
      array (
        0 => 
        array (
          'name' => 'http://localhost',
          'disks' => 
          array (
            0 => 'backups',
          ),
          'newestBackupsShouldNotBeOlderThanDays' => 1,
          'storageUsedMayNotBeHigherThanMegabytes' => 5000,
        ),
      ),
      'notifications' => 
      array (
        'handler' => 'Spatie\\Backup\\Notifications\\Notifier',
        'events' => 
        array (
          'whenBackupWasSuccessful' => 
          array (
            0 => 'log',
          ),
          'whenCleanupWasSuccessful' => 
          array (
            0 => 'log',
          ),
          'whenHealthyBackupWasFound' => 
          array (
            0 => 'log',
          ),
          'whenBackupHasFailed' => 
          array (
            0 => 'log',
            1 => 'mail',
          ),
          'whenCleanupHasFailed' => 
          array (
            0 => 'log',
            1 => 'mail',
          ),
          'whenUnHealthyBackupWasFound' => 
          array (
            0 => 'log',
            1 => 'mail',
          ),
        ),
        'mail' => 
        array (
          'from' => 'your@email.com',
          'to' => 'your@email.com',
        ),
        'slack' => 
        array (
          'channel' => '#backups',
          'username' => 'Backup bot',
          'icon' => ':robot:',
        ),
      ),
    ),
  ),
  'elfinder' => 
  array (
    'dir' => 
    array (
      0 => 'uploads',
    ),
    'disks' => 
    array (
      0 => 'uploads',
    ),
    'route' => 
    array (
      'prefix' => 'admin/elfinder',
      'middleware' => 
      array (
        0 => 'web',
        1 => 'admin',
      ),
    ),
    'access' => 'Barryvdh\\Elfinder\\Elfinder::checkAccess',
    'roots' => NULL,
    'options' => 
    array (
    ),
    'root_options' => 
    array (
    ),
  ),
  'breadcrumbs' => 
  array (
    'view' => 'breadcrumbs::bootstrap3',
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => '/home/iVanilla/website/storage/app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => '/home/iVanilla/website/storage/app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => NULL,
        'secret' => NULL,
        'region' => NULL,
        'bucket' => NULL,
      ),
      'backups' => 
      array (
        'driver' => 'local',
        'root' => '/home/iVanilla/website/storage/backups',
      ),
      'storage' => 
      array (
        'driver' => 'local',
        'root' => '/home/iVanilla/website/storage',
      ),
    ),
    'uploads' => 
    array (
      'driver' => 'local',
      'root' => '/home/iVanilla/website/public/uploads',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'passport',
        'provider' => 'users',
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
        'table' => 'users',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'larainvite' => 
  array (
    'expires' => 72,
    'UserModel' => 'App\\Models\\User',
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => 'your-public-key',
        'secret' => 'your-secret-key',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'UEditorUpload' => 
  array (
    'core' => 
    array (
      'route' => 
      array (
        'middleware' => 'auth',
      ),
      'mode' => 'local',
      'qiniu' => 
      array (
        'accessKey' => '',
        'secretKey' => '',
        'bucket' => '',
        'url' => 'http://xxx.clouddn.com',
      ),
    ),
    'upload' => 
    array (
      'imageActionName' => 'uploadimage',
      'imageFieldName' => 'upfile',
      'imageMaxSize' => 2048000,
      'imageAllowFiles' => 
      array (
        0 => '.png',
        1 => '.jpg',
        2 => '.jpeg',
        3 => '.gif',
        4 => '.bmp',
      ),
      'imageCompressEnable' => true,
      'imageCompressBorder' => 1600,
      'imageInsertAlign' => 'none',
      'imageUrlPrefix' => '',
      'imagePathFormat' => '/uploads/ueditor/php/upload/image/{yyyy}{mm}{dd}/{time}{rand:6}',
      'scrawlActionName' => 'uploadscrawl',
      'scrawlFieldName' => 'upfile',
      'scrawlPathFormat' => '/uploads/ueditor/php/upload/image/{yyyy}{mm}{dd}/{time}{rand:6}',
      'scrawlMaxSize' => 2048000,
      'scrawlUrlPrefix' => '',
      'scrawlInsertAlign' => 'none',
      'snapscreenActionName' => 'uploadimage',
      'snapscreenPathFormat' => '/uploads/ueditor/php/upload/image/{yyyy}{mm}{dd}/{time}{rand:6}',
      'snapscreenUrlPrefix' => '',
      'snapscreenInsertAlign' => 'none',
      'catcherLocalDomain' => 
      array (
        0 => '127.0.0.1',
        1 => 'localhost',
        2 => 'img.baidu.com',
      ),
      'catcherActionName' => 'catchimage',
      'catcherFieldName' => 'source',
      'catcherPathFormat' => '/uploads/ueditor/php/upload/image/{yyyy}{mm}{dd}/{time}{rand:6}',
      'catcherUrlPrefix' => '',
      'catcherMaxSize' => 2048000,
      'catcherAllowFiles' => 
      array (
        0 => '.png',
        1 => '.jpg',
        2 => '.jpeg',
        3 => '.gif',
        4 => '.bmp',
      ),
      'imageManagerActionName' => 'listimage',
      'imageManagerListPath' => '/uploads/ueditor/php/upload/image/',
      'imageManagerListSize' => 20,
      'imageManagerUrlPrefix' => '',
      'imageManagerInsertAlign' => 'none',
      'imageManagerAllowFiles' => 
      array (
        0 => '.png',
        1 => '.jpg',
        2 => '.jpeg',
        3 => '.gif',
        4 => '.bmp',
      ),
      'fileManagerActionName' => 'listfile',
      'fileManagerListPath' => '/uploads/ueditor/php/upload/file/',
      'fileManagerUrlPrefix' => '',
      'fileManagerListSize' => 20,
      'fileManagerAllowFiles' => 
      array (
        0 => '.png',
        1 => '.jpg',
        2 => '.jpeg',
        3 => '.gif',
        4 => '.bmp',
        5 => '.flv',
        6 => '.swf',
        7 => '.mkv',
        8 => '.avi',
        9 => '.rm',
        10 => '.rmvb',
        11 => '.mpeg',
        12 => '.mpg',
        13 => '.ogg',
        14 => '.ogv',
        15 => '.mov',
        16 => '.wmv',
        17 => '.mp4',
        18 => '.webm',
        19 => '.mp3',
        20 => '.wav',
        21 => '.mid',
        22 => '.rar',
        23 => '.zip',
        24 => '.tar',
        25 => '.gz',
        26 => '.7z',
        27 => '.bz2',
        28 => '.cab',
        29 => '.iso',
        30 => '.doc',
        31 => '.docx',
        32 => '.xls',
        33 => '.xlsx',
        34 => '.ppt',
        35 => '.pptx',
        36 => '.pdf',
        37 => '.txt',
        38 => '.md',
        39 => '.xml',
      ),
    ),
  ),
  'upload' => 
  array (
    'chunks' => '/home/iVanilla/website/storage/app/chunks',
    'storage' => '/home/iVanilla/website/public//storage/temp',
    'domain' => NULL,
    'path' => 'storage/temp',
  ),
  'entrust' => 
  array (
    'role' => 'App\\Models\\Role',
    'roles_table' => 'roles',
    'permission' => 'App\\Models\\Permission',
    'permissions_table' => 'permissions',
    'permission_role_table' => 'permission_role',
    'role_user_table' => 'role_user',
    'user_foreign_key' => 'user_id',
    'role_foreign_key' => 'role_id',
    'permission_foreign_key' => 'permission_id',
  ),
  'prologue' => 
  array (
    'alerts' => 
    array (
      'levels' => 
      array (
        0 => 'info',
        1 => 'warning',
        2 => 'error',
        3 => 'success',
      ),
      'session_key' => 'alert_messages',
    ),
  ),
  'image' => 
  array (
    'driver' => 'gd',
  ),
  0 => 'config/laravel-backup.php',
  'langfilemanager' => 
  array (
    'language_ignore' => 
    array (
      0 => 'pagination',
      1 => 'reminders',
      2 => 'validation',
      3 => 'log',
      4 => 'crud',
    ),
  ),
);
