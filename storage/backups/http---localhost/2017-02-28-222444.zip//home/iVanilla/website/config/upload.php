<?php

return [
    'chunks' => storage_path('app/chunks'),
    'storage' => public_path('/storage/temp'),
    'domain' => null,
    'path' => 'storage/temp',
];
