<?php

/*
  * Notifynder
  */
return [
    'user' => [
    	'welcome' => '{to.name}， 欢迎来到{app.name}!',
    	'reply' => '{from.name}回复了你的帖子"{topic.title}"',
    	'at' => '{from.name}在帖子"{topic.title}"中@了你', 
    	'following' => '{from.name}关注了你',
    	'vote' => '{from.name}点赞了你的帖子"{topic.title}"',
    	'privmsg' => '{from.name}给你发了私信', 
    ],
];