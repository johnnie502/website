@extends('layouts.app')
@section('title')
@stop
@section('content')
    <div class="panel">
        <div class="panel-body">
        </div>
    </div>
@stop